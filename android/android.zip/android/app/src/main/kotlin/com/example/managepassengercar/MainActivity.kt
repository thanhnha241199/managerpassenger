package com.example.managepassengercar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
